//
//  AppDelegate.h
//  HABannerDemo
//
//  Created by 周厚安 on 16/1/19.
//  Copyright © 2016年 周厚安. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

