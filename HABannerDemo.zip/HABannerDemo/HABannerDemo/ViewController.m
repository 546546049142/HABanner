//
//  ViewController.m
//  HABannerDemo
//
//  Created by 周厚安 on 16/1/19.
//  Copyright © 2016年 周厚安. All rights reserved.
//

#import "ViewController.h"
#import "HADirect.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //===============================Banner1 本地图片banner===============================
    
    NSMutableArray *imgNameArr=[NSMutableArray array];
    for(int i=1;i<5;i++)
    {
        [imgNameArr addObject:[NSString stringWithFormat:@"%d.jpg",i]];
    }
    HADirect *direct1=[HADirect direcWithtFrame:CGRectMake(0, 0, self.view.frame.size.width, 200) ImageNameArr:imgNameArr AndImageClickBlock:^(NSInteger index) {
        NSLog(@"%ld",(long)index);
    }];
    [self.view addSubview:direct1];
    
    
    //===============================Banner2 网络图片banner===============================
    NSArray *webImgAddressArr=@[@"http://img2.3lian.com/img2007/10/28/123.jpg",@"http://down.tutu001.com/d/file/20101129/2f5ca0f1c9b6d02ea87df74fcc_560.jpg",@"http://zx.kaitao.cn/UserFiles/Image/beijingtupian6.jpg"];
    
    HADirect *direct2=[HADirect direcWithtFrame:CGRectMake(0, 200, self.view.frame.size.width, 200) ImageNameArr:webImgAddressArr AndImageClickBlock:^(NSInteger index) {
        NSLog(@"%ld",(long)index);
    }];
    
    //使用占位图
    direct2.placeholderName=@"placeholder";
    [self.view addSubview:direct2];
    
    
    //===============================Banner3 完全自定义banner===============================
    NSMutableArray *customViewArr=[NSMutableArray array];
    NSArray *colorArr=@[[UIColor yellowColor],[UIColor blueColor],[UIColor purpleColor]];
    for(int i=0;i<colorArr.count;i++)
    {
        UIView *customView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 200)];
        customView.backgroundColor=colorArr[i];
        
        //添加文字
        UILabel *lab=[[UILabel alloc]initWithFrame:CGRectMake(50, 0, 200, 50)];
        lab.text=@"任意样式，欢迎使用!";
        lab.font=[UIFont systemFontOfSize:14];
        lab.textColor=[UIColor blackColor];
        [customView addSubview:lab];
        
        //添加图片
        UIImageView *imgView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:imgNameArr[i]]];
        imgView.frame=CGRectMake(300, 0, 80, 200);
        [customView addSubview:imgView];
        
        [customViewArr addObject:customView];
    }
    //传入自定义view即可
    HADirect *direct3=[HADirect direcWithtFrame:CGRectMake(0, 400, self.view.frame.size.width, 200) ViewArr:customViewArr AndClickBlock:^(NSInteger index) {
        NSLog(@"%ld",(long)index);
    }];
    [self.view addSubview:direct3];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
