//
//  HADirect.h
//  Test
//
//  Created by mac on 15/9/19.
//  Copyright (c) 2015年 HA. All rights reserved.
//


/*
 
 *********************************************************************************
 *
 * 🌟🌟🌟 欢迎使用HABanner 🌟🌟🌟
 *
 * 在您使用此自动轮播库的过程中如果出现bug请及时以以下任意一种方式联系我们，我们会及时修复bug并
 * 帮您解决问题。
 * Email : 546049142@qq.com
 * GitHub: https://github.com/546546049142/HABanner
 *
 *********************************************************************************
 
 */


#import <UIKit/UIKit.h>
#import "UIImageView+WebCache.h"

typedef void(^imageClickBlock)(NSInteger index);

@interface HADirect : UIView

//轮播的ScrollView
@property(strong,nonatomic) UIScrollView *direct;
//轮播的页码
@property(strong,nonatomic) UIPageControl *pageVC;
//轮播滚动时间间隔
@property(assign,nonatomic) CGFloat time;
//网络加载可以选择需要使用的占为图片
@property(nonatomic,strong) NSString *placeholderName;

#pragma mark 初始化图片格式的HADirect
+(instancetype)direcWithtFrame:(CGRect)frame ImageNameArr:(NSArray *)imageNameArray AndImageClickBlock:(imageClickBlock)clickBlock;

#pragma mark 初始化自定义样式的HADirect
+(instancetype)direcWithtFrame:(CGRect)frame ViewArr:(NSArray *)customViewArr AndClickBlock:(imageClickBlock)clickBlock;

#pragma mark 开始定时器
-(void)beginTimer;

#pragma mark 销毁定时器
-(void)stopTimer;

#pragma mark 自定义UIPageControl样式（图片大小要合适）
-(void)customPageVcWithSelectedImg:(UIImage *)selectedImg NormalImg:(UIImage *)normalImg;
@end
